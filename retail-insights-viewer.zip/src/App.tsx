import React, { useState, useRef, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Upload, Info, AlertTriangle, CheckCircle2, 
  FileSpreadsheet, X, Download, ArrowUpRight, 
  Clock, TrendingUp, DollarSign, Package,
  Maximize2
} from 'lucide-react';
import { BASE_FIXTURES, COLORS } from './constants';
import { 
  MetricType, BrandAnalytics, FixtureMeta, ArticleStat 
} from './types';
import { 
  parseExcel, formatCurrency, formatPercent, 
  formatNumber, downloadExcelTemplate 
} from './utils';

export default function App() {
  const [metric, setMetric] = useState<MetricType>('Performance');
  const [data, setData] = useState<{
    analytics: BrandAnalytics[];
    lastDate: string;
    weeks: number;
    percentiles: Record<string, { p33: number; p67: number }>;
  } | null>(null);
  
  const [isUploading, setIsUploading] = useState(false);
  const [hoveredFixture, setHoveredFixture] = useState<FixtureMeta | null>(null);
  const [selectedBrand, setSelectedBrand] = useState<BrandAnalytics | null>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [panelWidth, setPanelWidth] = useState(360);
  const [isResizing, setIsResizing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isResizing) return;
      const newWidth = window.innerWidth - e.clientX;
      setPanelWidth(Math.min(560, Math.max(260, newWidth)));
    };

    const handleMouseUp = () => setIsResizing(false);

    if (isResizing) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      document.addEventListener('mouseleave', handleMouseUp);
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      document.removeEventListener('mouseleave', handleMouseUp);
    };
  }, [isResizing]);

  const brandMap = useMemo(() => {
    const map = new Map<string, BrandAnalytics>();
    data?.analytics.forEach(b => map.set(b.brand.toLowerCase(), b));
    return map;
  }, [data]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setIsUploading(true);
      try {
        const result = await parseExcel(file);
        setData(result);
      } catch (err) {
        console.error(err);
        alert(err instanceof Error ? err.message : 'Failed to parse Excel file.');
      } finally {
        setIsUploading(false);
      }
    }
  };

  // Map brands to fixtures based on dynamic data
  const mappedFixtures = useMemo(() => {
    if (!data) return [];

    const result: FixtureMeta[] = [];
    const analytics = data.analytics;

    // Fix 2: Dynamic Wallbays (only render what exists)
    const skinBrands = analytics.filter(b => b.fixtureId.startsWith('Skin Wallbay'));
    const fragBrands = analytics.filter(b => b.fixtureId.startsWith('Wallbay Fragrance'));

    // Fix 8: Floor Padding and Dimensions
    const sidePadding = 14;
    const startX = sidePadding;

    skinBrands.forEach((b, i) => {
      result.push({
        id: `sw-${i}`,
        fixtureRef: b.fixtureId,
        type: 'wallbay',
        brand: b.brand,
        x: startX + i * 94,
        y: 15,
        w: 90,
        h: 36
      });
    });

    const fragOffset = startX + skinBrands.length * 94 + 10;
    fragBrands.forEach((b, i) => {
      result.push({
        id: `fw-${i}`,
        fixtureRef: b.fixtureId,
        type: 'wallbay',
        brand: b.brand,
        x: fragOffset + i * 56,
        y: 15,
        w: 52,
        h: 36
      });
    });

    // Fix 8: Gondola Grid
    // Total height of 96px: A=44, B=42, spine=1. Next begins after 16px gap.
    const viewWidth = 520;
    const gWidth = 416;
    const gX = (viewWidth - gWidth) / 2;
    const segmentW = gWidth / 2; // Exactly 50%

    ['G1', 'G-2', 'G-3', 'G-4'].forEach((ref, i) => {
      const gBrands = analytics.filter(b => b.fixtureId === ref);
      const rowY = 60 + i * 112; // 96px + 16px gap = 112
      const baseColors: Record<string, string> = { 'G1': '#8b5cf6', 'G-2': '#14b8a6', 'G-3': '#ec4899', 'G-4': '#f59e0b' };
      const defaultColor = baseColors[ref] || '#fff';

      gBrands.slice(0, 4).forEach((b, idx) => {
        const side: 'A' | 'B' = idx < 2 ? 'A' : 'B';
        const isLeft = idx % 2 === 0;
        
        // Side A is 44px, Side B is 42px. Divider is at y + 44
        const segmentH = side === 'A' ? 44 : 42;
        const segmentY = rowY + (side === 'B' ? 45 : 0); // 44 + 1 (spine) = 45

        result.push({
          id: `${ref}-${idx}`,
          fixtureRef: ref,
          type: 'gondola-segment',
          side,
          brand: b.brand,
          x: gX + (isLeft ? 0 : segmentW),
          y: segmentY,
          w: segmentW,
          h: segmentH,
          defaultColor
        });
      });
    });

    return result;
  }, [data]);

  const getFixtureStyle = (fixture: FixtureMeta) => {
    const b = fixture.brand ? brandMap.get(fixture.brand.toLowerCase()) : null;
    let fill = fixture.type === 'wallbay' ? COLORS.floor : (fixture.defaultColor || '#fff');
    let stroke = '#1a1714';
    let textCol = '#1a1714';

    if (!b) return { fill: COLORS.missing, stroke: '#aaa', text: '#666', dash: '4,4' };

    // Fix 3: Metric colours only apply when metric tab is NOT Performance
    if (metric !== 'Performance') {
      const val = metric === 'SPSF' ? b.spsf : metric === 'GMROF' ? b.gmrof : b.contributionPct;
      const p = data?.percentiles[metric];
      if (p) {
        if (val >= p.p67) { fill = COLORS.green.fill; stroke = COLORS.green.stroke; textCol = COLORS.green.text; }
        else if (val >= p.p33) { fill = COLORS.amber.fill; stroke = COLORS.amber.stroke; textCol = COLORS.amber.text; }
        else { fill = COLORS.red.fill; stroke = COLORS.red.stroke; textCol = COLORS.red.text; }
      }
    } else {
      // Fix 3: Performance tab wallbays are neutral no-fill
      if (fixture.type === 'wallbay') fill = COLORS.floor;
    }

    return { fill, stroke, text: textCol, dash: '0' };
  };

  const getStockDotColor = (status: BrandAnalytics['stockStatus']) => {
    if (status === 'OOS' || status === 'CRITICAL') return COLORS.red.fill;
    if (status === 'RISKY') return COLORS.amber.fill;
    return COLORS.green.fill;
  };

  const performanceCards = useMemo(() => {
    if (!data) return [];
    const groups = {
      OOS: data.analytics.filter(b => b.stockStatus === 'OOS').sort((a,b) => b.totalQty - a.totalQty),
      CRITICAL: data.analytics.filter(b => b.stockStatus === 'CRITICAL').sort((a,b) => b.totalQty - a.totalQty),
      RISKY: data.analytics.filter(b => b.stockStatus === 'RISKY').sort((a,b) => b.totalQty - a.totalQty),
    };
    return [
      { id: 'OOS', label: 'Out of stock', items: groups.OOS },
      { id: 'CRITICAL', label: 'Critical · <2w cover', items: groups.CRITICAL },
      { id: 'RISKY', label: 'Risky · 2–4w cover', items: groups.RISKY },
    ].filter(g => g.items.length > 0);
  }, [data]);

  const sortedTableData = useMemo(() => {
    if (!data || metric === 'Performance') return [];
    const key = metric === 'SPSF' ? 'spsf' : metric === 'GMROF' ? 'gmrof' : 'contributionPct';
    return [...data.analytics].sort((a, b) => (b[key] as number) - (a[key] as number));
  }, [data, metric]);

  // Fix 9: Text autofitting logic
  const getTextProps = (text: string, maxWidth: number) => {
    const chars = text.length;
    let fontSize = 9;
    if (chars > 22) fontSize = 7.5;
    else if (chars > 16) fontSize = 8;

    const availableWidth = maxWidth - 16;
    // Heuristic: Check if likely to overflow. DM Sans 9px usually ~5px/char.
    const estimatedWidth = chars * (fontSize * 0.55);
    const useTextLength = estimatedWidth > availableWidth;

    return {
      fontSize: `${fontSize}px`,
      textLength: useTextLength ? availableWidth : undefined,
      lengthAdjust: useTextLength ? "spacingAndGlyphs" as const : undefined
    };
  };

  const gondolaRefs = ['G1', 'G-2', 'G-3', 'G-4'];
  const floorViewHeight = 60 + (gondolaRefs.length * 112) + 40 + 20;

  const handleDownloadTemplate = () => {
    const analytics = data ? data.analytics : mappedFixtures;
    downloadExcelTemplate(analytics);
  };

  return (
    <div className="flex flex-col h-screen bg-white select-none">
      {/* Header Bar */}
      <header className="h-10 bg-[#1a1714] text-white flex items-center justify-between px-6 shrink-0 z-10">
        <h1 className="text-[12px] font-bold uppercase tracking-widest text-[#e8e3da]">
          Store Efficiency Viewer — Beauty & Personal Care
        </h1>
        <div className="mono text-[11px] font-medium text-[#888] tracking-tighter uppercase">
          {data?.lastDate || 'Last Refresh: 18 APR 2026'}
        </div>
      </header>

      {/* Toolbar */}
      <nav className="h-14 bg-white border-b border-[#e2ddd6] flex items-center justify-between px-6 shrink-0 z-10 transition-colors">
        <div className="flex items-center gap-1.5">
          {(['Performance', 'SPSF', 'GMROF', 'Contribution %'] as MetricType[]).map((m) => (
            <button
              key={m}
              onClick={() => setMetric(m)}
              className={`px-4 py-1.5 text-[12px] font-semibold rounded-full transition-all border ${
                metric === m 
                  ? 'bg-[#1a1714] text-white border-[#1a1714]' 
                  : 'bg-white text-[#666] border-[#e2ddd6] hover:bg-[#f7f4ef]'
              }`}
            >
              {m}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${data ? 'bg-green-500' : 'bg-amber-500'} animate-pulse`} />
            <span className="text-[11px] font-medium text-[#666] uppercase tracking-wider">
              {isUploading ? 'Parsing data...' : data ? 'Data Live' : 'Waiting for upload'}
            </span>
          </div>
          
          <div className="h-6 w-[1px] bg-[#e2ddd6]" />
          
          <button 
            onClick={handleDownloadTemplate}
            className="flex items-center gap-1.5 px-3 py-1.5 text-[11px] font-bold text-[#1a1714] hover:bg-[#f7f4ef] rounded-md transition-colors uppercase tracking-widest"
          >
            <Download size={14} />
            Template
          </button>
          
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-5 py-1.5 bg-[#1a1714] text-white text-[12px] font-bold rounded-md hover:bg-black transition-all active:scale-95 shadow-sm uppercase tracking-widest"
          >
            <Upload size={14} />
            Upload data
          </button>
          <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept=".xlsx,.xls" className="hidden" />
        </div>
      </nav>

      {/* Main Row */}
      <div className="flex flex-1 overflow-hidden">
        {/* Floor Plan Column */}
        <section className="flex-1 bg-[#f7f4ef] p-10 overflow-auto flex items-center justify-center relative">
          <div className="bg-[#f0ece3] rounded-[10px] p-[14px] shadow-[inset_0_0_40px_rgba(0,0,0,0.03)] border border-[#e2ddd6] relative">
            <svg 
              viewBox={`0 0 520 ${floorViewHeight}`} 
              className="w-[850px] h-auto drop-shadow-sm"
              onMouseMove={(e) => setMousePos({ x: e.clientX, y: e.clientY })}
            >
              <rect width="520" height={floorViewHeight} fill="#e8e3da" rx="8" />
              
              {/* Gondola Labels (Fix 8) */}
              {gondolaRefs.map((ref, i) => (
                <text 
                  key={`label-${ref}`}
                  x={520 / 2 - 416 / 2}
                  y={60 + i * 112 - 12}
                  className="mono text-[10px] fill-gray-500 font-medium"
                >
                  {ref}
                </text>
              ))}

              {/* Gondola Outer Borders (Fix 8) */}
              {gondolaRefs.map((ref, i) => (
                <rect 
                  key={`border-${ref}`}
                  x={520 / 2 - 416 / 2}
                  y={60 + i * 112}
                  width="416"
                  height="96"
                  fill="none"
                  stroke="#1a1714"
                  strokeWidth="0.5"
                  strokeDasharray="5,3"
                  rx="5"
                  opacity="0.2"
                />
              ))}

              {/* Fixtures Mapping */}
              {mappedFixtures.map((f) => {
                const s = getFixtureStyle(f);
                const b = f.brand ? brandMap.get(f.brand.toLowerCase()) : null;
                const textProps = getTextProps(f.brand || '-', f.w);

                return (
                  <g 
                    key={f.id} 
                    className="cursor-pointer transition-opacity"
                    onMouseEnter={() => setHoveredFixture(f)}
                    onMouseLeave={() => setHoveredFixture(null)}
                    onClick={() => b && setSelectedBrand(b)}
                  >
                    <rect 
                      x={f.x} y={f.y} width={f.w} height={f.h}
                      fill={s.fill} stroke={s.stroke} strokeWidth="0.8"
                      strokeDasharray={s.dash} 
                      opacity={f.side === 'B' ? 0.55 : 1}
                      className="transition-all duration-300"
                    />
                    
                    {/* Brand Label (Fix 9) */}
                    <text 
                      x={f.x + f.w/2} y={f.y + f.h/2} 
                      textAnchor="middle" dominantBaseline="middle"
                      className="font-semibold pointer-events-none tracking-tighter"
                      style={{ fill: s.text, fontSize: textProps.fontSize }}
                      textLength={textProps.textLength}
                      lengthAdjust={textProps.lengthAdjust}
                    >
                      {f.brand || '-'}
                    </text>

                    {/* Stock Health Dot (Gondolas Side A only) */}
                    {f.side === 'A' && b && (
                      <circle 
                        cx={f.x + f.w - 8} cy={f.y + 8} r="3.5"
                        fill={getStockDotColor(b.stockStatus)}
                        className="animate-pulse"
                      />
                    )}

                    {/* Gondola Side Divider (Spine - Fix 8) */}
                    {f.side === 'A' && (
                       <line x1={f.x} y1={f.y + f.h} x2={f.x + f.w} y2={f.y + f.h} stroke="#1a1714" strokeWidth="1" />
                    )}
                  </g>
                );
              })}
            </svg>
          </div>
        </section>

        {/* Tooltip */}
        <AnimatePresence>
          {hoveredFixture && hoveredFixture.brand && brandMap.get(hoveredFixture.brand.toLowerCase()) && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed z-[9999] bg-[#1a1714] text-white p-3 rounded-lg shadow-2xl min-w-[180px] pointer-events-none"
              style={{ left: mousePos.x + 14, top: mousePos.y - 12 }}
            >
              <div className="text-[10px] text-[#888] uppercase tracking-widest font-bold mb-1 border-b border-white/10 pb-1">
                {hoveredFixture.brand}
              </div>
              {(() => {
                const b = brandMap.get(hoveredFixture.brand!.toLowerCase())!;
                return (
                  <div className="space-y-1.5 mt-2">
                    <div className="flex justify-between items-baseline gap-4">
                      <span className="text-[9px] text-white/50 uppercase">Sales</span>
                      <span className="mono text-[12px]">{formatCurrency(b.totalSales)}</span>
                    </div>
                    <div className="flex justify-between items-baseline gap-4">
                      <span className="text-[9px] text-white/50 uppercase">{metric}</span>
                      <span className="mono text-[12px] font-bold text-[#eaff00]">
                        {metric === 'Contribution %' ? formatPercent(b.contributionPct) : 
                         metric === 'SPSF' ? formatCurrency(b.spsf) : 
                         metric === 'GMROF' ? formatCurrency(b.gmrof) : '₹' + Math.round(b.totalSales)}
                      </span>
                    </div>
                    <div className="flex justify-between items-baseline gap-4 pt-1 border-t border-white/10">
                      <span className="text-[9px] text-white/50 uppercase">Stock Cover</span>
                      <span className={`mono text-[12px] ${getStockDotColor(b.stockStatus) === COLORS.red.fill ? 'text-red-400' : 'text-green-400'}`}>
                        {b.worstNWC < 90 ? b.worstNWC.toFixed(1)+'w' : 'OK'}
                      </span>
                    </div>
                  </div>
                );
              })()}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Resize Handle */}
        <div 
          onMouseDown={() => setIsResizing(true)}
          className="w-[6px] cursor-col-resize bg-[#f0ece3] border-l border-r border-[#e2ddd6] flex items-center justify-center hover:bg-[#e8e3da] transition-colors z-20"
        >
          <div className="flex flex-col gap-[3px]">
            <div className="w-[3px] h-[1px] bg-[#d3d1c7]" />
            <div className="w-[3px] h-[1px] bg-[#d3d1c7]" />
            <div className="w-[3px] h-[1px] bg-[#d3d1c7]" />
          </div>
        </div>

        {/* Right Panel */}
        <aside 
          style={{ width: panelWidth }} 
          className="bg-white border-l border-[#e2ddd6] flex flex-col shrink-0 overflow-hidden"
        >
          {/* Summary Strip */}
          <div className="grid grid-cols-3 divide-x divide-[#e2ddd6] border-b border-[#e2ddd6] bg-[#f7f4ef]/30 h-16 shrink-0">
            <div className="flex flex-col items-center justify-center">
              <span className="text-[10px] text-[#888] uppercase tracking-tighter">Brands</span>
              <span className="mono text-[16px] font-bold">{data?.analytics.length || 0}</span>
            </div>
            <div className={`flex flex-col items-center justify-center ${performanceCards.find(g=>g.id==='OOS') ? 'bg-red-50' : ''}`}>
              <span className="text-[10px] text-[#888] uppercase tracking-tighter">OOS/Crit</span>
              <span className="mono text-[16px] font-bold text-red-500">
                {(performanceCards.find(g => g.id === 'OOS')?.items.length || 0) + (performanceCards.find(g => g.id === 'CRITICAL')?.items.length || 0)}
              </span>
            </div>
            <div className={`flex flex-col items-center justify-center ${performanceCards.find(g=>g.id==='RISKY') ? 'bg-amber-50' : ''}`}>
              <span className="text-[10px] text-[#888] uppercase tracking-tighter">Risky</span>
              <span className="mono text-[16px] font-bold text-amber-600">
                {performanceCards.find(g => g.id === 'RISKY')?.items.length || 0}
              </span>
            </div>
          </div>

          <div className="p-4 flex flex-col flex-1 overflow-hidden">
            <div className="mb-4">
              <h2 className="text-[15px] font-black tracking-tight">{metric} Analysis</h2>
              <p className="text-[10px] text-gray-500 tracking-tight uppercase">
                {metric === 'Performance' ? 'Prioritised Stock Health Alerts' : 
                 `Percentile split · p33=${formatCurrency(data?.percentiles[metric].p33 || 0)} · p67=${formatCurrency(data?.percentiles[metric].p67 || 0)}`}
              </p>
            </div>

            <div className="flex-1 overflow-y-auto no-scrollbar">
              {metric === 'Performance' ? (
                <div className="space-y-6">
                  {data ? (
                    performanceCards.length > 0 ? performanceCards.map(group => (
                      <div key={group.id}>
                        <div className="flex items-center gap-2 mb-3">
                          <span className={`h-1.5 w-1.5 rounded-full ${group.id === 'OOS' ? 'bg-red-500' : group.id === 'CRITICAL' ? 'bg-red-400' : 'bg-amber-500'}`} />
                          <span className="text-[10px] font-black uppercase tracking-widest text-gray-400">{group.label}</span>
                        </div>
                        <div className="space-y-2">
                          {group.items.map(b => (
                            <div 
                              key={b.brand}
                              onClick={() => setSelectedBrand(b)}
                              className="group p-3 border border-[#e2ddd6] rounded-lg bg-white hover:border-[#1a1714] transition-all cursor-pointer relative"
                            >
                               <div className="flex justify-between items-start mb-1">
                                 <h4 className="text-[12px] font-bold">{b.brand}</h4>
                                 <ArrowUpRight size={12} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                               </div>
                               <div className="flex gap-1 mb-2">
                                 <span className={`text-[8px] px-1.5 py-0.5 rounded-full font-bold uppercase ${
                                   b.portfolio === 'CC' ? 'bg-purple-100 text-purple-700' : 
                                   b.portfolio === 'Skin' ? 'bg-blue-100 text-blue-700' : 'bg-pink-100 text-pink-700'
                                 }`}>
                                   {b.portfolio}
                                 </span>
                                 <span className="text-[8px] px-1.5 py-0.5 bg-gray-100 text-gray-600 rounded-full font-bold uppercase">{b.fixtureId}</span>
                               </div>
                               <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-dashed border-gray-100">
                                 <div className="flex flex-col">
                                   <span className="text-[8px] text-gray-400 uppercase">Qty</span>
                                   <span className="text-[11px] mono font-bold">{b.totalQty}</span>
                                 </div>
                                 <div className="flex flex-col">
                                   <span className="text-[8px] text-gray-400 uppercase">Sales</span>
                                   <span className="text-[11px] mono font-bold">{formatCurrency(b.totalSales)}</span>
                                 </div>
                               </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )) : (
                      <div className="flex flex-col items-center justify-center pt-10 text-center text-gray-400">
                        <CheckCircle2 size={32} className="mb-3 text-green-500 opacity-20" />
                        <p className="text-[11px] font-medium italic">No critical stock alerts detected</p>
                      </div>
                    )
                  ) : (
                    <div className="flex flex-col items-center justify-center pt-10 text-center">
                      <FileSpreadsheet size={32} className="mb-3 text-gray-200" />
                      <p className="text-[11px] text-gray-400 leading-relaxed max-w-[180px]">
                        Upload Excel data to see operational priorities
                      </p>
                    </div>
                  )}
                </div>
              ) : (
                <table className="w-full text-left table-fixed">
                  <thead className="sticky top-0 bg-white z-10">
                    <tr className="border-b border-gray-100">
                      <th className="py-2 text-[9px] font-black uppercase tracking-widest text-gray-400 w-full px-2">Brand</th>
                      <th className="py-2 text-[9px] font-black uppercase tracking-widest text-gray-400 text-right w-[100px] px-2">{metric}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {sortedTableData.map(b => {
                      const val = metric === 'SPSF' ? b.spsf : metric === 'GMROF' ? b.gmrof : b.contributionPct;
                      const p = data?.percentiles[metric];
                      const tier = p ? (val >= p.p67 ? 'green' : val >= p.p33 ? 'amber' : 'red') : 'gray';
                      return (
                        <tr key={b.brand} className="hover:bg-gray-50 cursor-pointer transition-colors" onClick={() => setSelectedBrand(b)}>
                          <td className="py-2 px-2 overflow-hidden">
                            <div className="flex flex-col gap-0.5 max-w-full">
                              <span className="text-[12px] font-bold truncate">{b.brand}</span>
                              <div className="flex items-center gap-1">
                                <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${
                                  tier === 'green' ? 'bg-[#3aaa6e]' : tier === 'amber' ? 'bg-[#EF9F27]' : 'bg-[#E24B4A]'
                                }`} />
                                <span className="text-[9px] text-gray-400 uppercase font-medium truncate">{b.portfolio}</span>
                              </div>
                            </div>
                          </td>
                          <td className="py-2 px-2 text-right font-bold mono text-[12px] whitespace-nowrap">
                            {metric === 'Contribution %' ? formatPercent(val) : formatCurrency(val)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>
            
            <div className="mt-4 pt-4 border-t border-[#e2ddd6] space-y-3 shrink-0">
               <div className="flex items-center justify-between">
                 <span className="text-[9px] font-black uppercase text-gray-400">Perf Scale</span>
                 <div className="flex gap-2">
                   {['red', 'amber', 'green'].map(c => (
                     <div key={c} className="flex items-center gap-1">
                       <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: COLORS[c as 'red'|'amber'|'green'].fill }} />
                       <span className="text-[8px] uppercase tracking-tighter text-gray-500">{c}</span>
                     </div>
                   ))}
                 </div>
               </div>
               <div className="h-1 w-full bg-gradient-to-r from-[#E24B4A] via-[#EF9F27] to-[#3aaa6e] rounded-full opacity-30" />
               <div className="flex items-center justify-between">
                 <span className="text-[9px] font-black uppercase text-gray-400">Stock Health</span>
                 <div className="flex gap-2">
                    <div className="flex items-center gap-1">
                      <div className="w-1.5 h-1.5 rounded-full bg-red-500" />
                      <span className="text-[8px] uppercase tracking-tighter text-gray-500">OOS/Crit</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <div className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                      <span className="text-[8px] uppercase tracking-tighter text-gray-500">Risky</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
                      <span className="text-[8px] uppercase tracking-tighter text-gray-500">Healthy</span>
                    </div>
                 </div>
               </div>
            </div>
          </div>
        </aside>
      </div>

      {/* Drill-down Modal */}
      <AnimatePresence>
        {selectedBrand && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/40 backdrop-blur-sm" onClick={() => setSelectedBrand(null)}>
            <motion.div 
               initial={{ opacity: 0, scale: 0.9, y: 20 }}
               animate={{ opacity: 1, scale: 1, y: 0 }}
               exit={{ opacity: 0, scale: 0.9, y: 20 }}
               className="bg-white rounded-[20px] shadow-2xl w-full max-w-[680px] max-h-[86vh] flex flex-col overflow-hidden" 
               onClick={(e) => e.stopPropagation()}
            >
              <div className="p-8 border-b border-gray-100 flex justify-between items-start relative">
                <div>
                   <div className="flex items-center gap-2 mb-2">
                     <span className={`text-[10px] px-2 py-0.5 rounded-full font-black uppercase ${
                       selectedBrand.portfolio === 'CC' ? 'bg-purple-100 text-purple-700' : 
                       selectedBrand.portfolio === 'Skin' ? 'bg-blue-100 text-blue-700' : 'bg-pink-100 text-pink-700'
                     }`}>
                       {selectedBrand.portfolio}
                     </span>
                     <span className="text-[10px] px-2 py-0.5 bg-gray-100 text-gray-600 rounded-full font-black uppercase">{selectedBrand.fixtureId}</span>
                   </div>
                   <h2 className="text-3xl font-black tracking-tighter text-[#1a1714]">{selectedBrand.brand}</h2>
                   <div className="flex items-center gap-2 mt-2">
                     <div className={`w-2.5 h-2.5 rounded-full ${getStockDotColor(selectedBrand.stockStatus)}`} />
                     <span className="text-[11px] font-bold uppercase tracking-widest" style={{ color: getStockDotColor(selectedBrand.stockStatus) }}>
                       {selectedBrand.stockStatus} STATUS
                     </span>
                   </div>
                </div>
                <button 
                  onClick={() => setSelectedBrand(null)}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-400 hover:text-gray-900"
                >
                  <X size={24} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-8 no-scrollbar">
                {/* 2x2 Grid Stats */}
                <div className="grid grid-cols-4 gap-4 mb-10">
                   {[
                     { label: 'SPSF', val: formatCurrency(selectedBrand.spsf), metric: 'SPSF' },
                     { label: 'GMROF', val: formatCurrency(selectedBrand.gmrof), metric: 'GMROF' },
                     { label: 'Contibution', val: formatPercent(selectedBrand.contributionPct), metric: 'Contribution %' },
                     { label: 'Worst NWC', val: selectedBrand.worstNWC.toFixed(1) + 'w', metric: 'NWC' }
                   ].map(stat => {
                     let color = '#3aaa6e';
                     if (stat.metric === 'NWC') {
                        if (selectedBrand.worstNWC < 2) color = COLORS.red.fill;
                        else if (selectedBrand.worstNWC < 4) color = COLORS.amber.fill;
                     } else {
                        const p = data?.percentiles[stat.metric];
                        const key = stat.metric === 'SPSF' ? 'spsf' : stat.metric === 'GMROF' ? 'gmrof' : 'contributionPct';
                        const v = selectedBrand[key as 'spsf' | 'gmrof' | 'contributionPct'];
                        if (p && v < p.p33) color = COLORS.red.fill;
                        else if (p && v < p.p67) color = COLORS.amber.fill;
                     }
                     return (
                       <div key={stat.label} className="bg-[#f7f4ef]/50 p-4 rounded-xl border border-[#e2ddd6]/50">
                         <span className="text-[10px] font-black uppercase text-gray-400 block mb-1">{stat.label}</span>
                         <span className="text-lg mono font-bold block" style={{ color }}>{stat.val}</span>
                       </div>
                     );
                   })}
                </div>

                {/* Article Table */}
                <div className="mb-10">
                  <h3 className="text-[13px] font-black uppercase tracking-widest mb-4 flex items-center gap-2">
                    <Package size={14} className="text-gray-400" />
                    Top-selling articles — stock impact
                  </h3>
                  <div className="overflow-hidden rounded-xl border border-gray-100">
                    <table className="w-full text-left table-fixed">
                      <thead className="bg-gray-50 border-b border-gray-100">
                        <tr>
                          <th className="px-3 py-2 text-[9px] font-black uppercase text-gray-400 w-[180px]">Article</th>
                          <th className="px-2 py-2 text-[9px] font-black uppercase text-gray-400 text-center">Velocity (w)</th>
                          <th className="px-2 py-2 text-[9px] font-black uppercase text-gray-400 text-center">SOH</th>
                          <th className="px-2 py-2 text-[9px] font-black uppercase text-gray-400 text-center">NWC (w)</th>
                          <th className="px-2 py-2 text-[9px] font-black uppercase text-gray-400 text-center">Days left</th>
                          <th className="px-3 py-2 text-[9px] font-black uppercase text-gray-400 text-right">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100">
                        {selectedBrand.topArticles.map(art => (
                          <tr key={art.articleId} className="hover:bg-gray-50">
                            <td className="px-3 py-2 overflow-hidden">
                              <span className="text-[11px] font-bold block leading-tight truncate">{art.description}</span>
                              <span className="text-[9px] mono text-gray-400">{art.articleId}</span>
                            </td>
                            <td className="px-2 py-2 text-center mono text-[11px] whitespace-nowrap">{art.velocity.toFixed(1)}</td>
                            <td className={`px-2 py-2 text-center mono text-[11px] whitespace-nowrap ${art.soh <= 0 ? 'text-red-500 font-bold' : ''}`}>{art.soh}</td>
                            <td className="px-2 py-2 text-center">
                              <div className="flex items-center justify-center gap-1">
                                <span className="mono text-[11px] whitespace-nowrap">{art.nwc < 99 ? art.nwc.toFixed(1) : '99+'}</span>
                              </div>
                            </td>
                            <td className="px-2 py-2 text-center mono text-[11px] whitespace-nowrap">{art.nwc < 99 ? Math.round(art.daysLeft) : '∞'}</td>
                            <td className="px-3 py-2 text-right">
                              <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-black uppercase whitespace-nowrap ${
                                art.status === 'OOS' ? 'bg-red-100 text-red-700' : 
                                art.status === 'CRITICAL' ? 'bg-red-50 text-red-500' : 
                                art.status === 'RISKY' ? 'bg-amber-50 text-amber-600' : 'bg-green-50 text-green-700'
                              }`}>
                                {art.status}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Insight Paragraph */}
                <div className="bg-[#1a1714] text-[#e8e3da] p-6 rounded-2xl relative overflow-hidden">
                   <div className="flex items-start gap-3 relative z-10">
                     <TrendingUp className="shink-0 text-amber-400" size={20} />
                     <div>
                       <h4 className="text-[11px] font-black uppercase tracking-widest text-white/40 mb-2">Efficiency Insight</h4>
                       <p className="text-[13px] leading-relaxed">
                          {(() => {
                            const worst = selectedBrand.topArticles.find(a => a.nwc === selectedBrand.worstNWC) || selectedBrand.topArticles[0];
                            if (selectedBrand.stockStatus === 'OOS' || selectedBrand.stockStatus === 'CRITICAL') {
                              return `${selectedBrand.brand} is facing a severe supply gap. ${worst.soh <= 0 ? 'Core SKUs are currently out of stock' : 'Stock for ' + worst.description + ' will deplete in less than ' + Math.round(worst.daysLeft) + ' days'}. With a weekly sell rate of ${worst.velocity.toFixed(1)} units, this core assortment is driving ${formatCurrency(selectedBrand.totalSales)} in total sales risk. Emergency replenishment is required to prevent further revenue erosion.`;
                            }
                            if (selectedBrand.stockStatus === 'RISKY') {
                               return `${selectedBrand.brand} has moderate stock risk. Inventory levels for ${worst.description} (${worst.nwc.toFixed(1)}w cover) are approaching thresholds that may impact weekend peaks. Total store contribution is ${formatPercent(selectedBrand.contributionPct)}. Recommended to trigger replenishment batch within 48 hours to maintain healthy shelf presence.`;
                            }
                            return `${selectedBrand.brand} is maintaining healthy inventory health across its top-performing assortment. With ${selectedBrand.worstNWC.toFixed(1)} weeks of minimal cover and a solid SPSF of ${formatCurrency(selectedBrand.spsf)}, focus should remain on maximizing promotional visibility on-floor to sustain this momentum.`;
                          })()}
                       </p>
                     </div>
                   </div>
                   <div className="absolute top-0 right-0 p-4 opacity-5">
                     <Package size={80} />
                   </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
