import * as XLSX from 'xlsx';
import { 
  StoreRow, SalesRow, SOHRow, BrandAnalytics, 
  ArticleStat, MetricType, FixtureMeta 
} from './types';

export const parseExcel = async (file: File): Promise<{ 
  analytics: BrandAnalytics[], 
  lastDate: string,
  weeks: number,
  percentiles: Record<string, { p33: number, p67: number }> 
}> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        
        const storeSheet = workbook.Sheets['Store_data_template'];
        // Note: Trailing space in "Sales "
        const salesSheet = workbook.Sheets['Sales '] || workbook.Sheets['Sales'];
        const sohSheet = workbook.Sheets['SOH'];

        if (!storeSheet || !salesSheet || !sohSheet) {
          throw new Error('Required sheets missing. Please check the template tabs (Store_data_template, Sales , SOH).');
        }

        const storeData = XLSX.utils.sheet_to_json(storeSheet) as StoreRow[];
        const salesData = XLSX.utils.sheet_to_json(salesSheet) as SalesRow[];
        const sohData = XLSX.utils.sheet_to_json(sohSheet) as SOHRow[];

        // 1. Calculate Weeks
        const uniqueDays = new Set(salesData.map(s => s.Date)).size;
        const weeks = Math.max(uniqueDays / 7, 1); // fallback to 1 to avoid div by zero

        // 2. Aggregate SOH (sum duplicate article rows)
        const sohMap = new Map<string, number>(); // article -> qty
        sohData.forEach(row => {
          const article = String(row.Article);
          sohMap.set(article, (sohMap.get(article) || 0) + (row['Saleable Qty'] || 0));
        });

        // 3. Process Sales by Brand and Article
        const brandSales = new Map<string, { 
          totalSales: number, 
          totalRGM: number, 
          totalQty: number,
          articles: Map<string, { description: string, qty: number }>
        }>();

        salesData.forEach(s => {
          const brand = s.Brand;
          const articleId = String(s['Article ID']);
          
          if (!brandSales.has(brand)) {
            brandSales.set(brand, { 
              totalSales: 0, totalRGM: 0, totalQty: 0, 
              articles: new Map() 
            });
          }
          
          const b = brandSales.get(brand)!;
          b.totalSales += s['Net Sales'] || 0;
          b.totalRGM += s.RGM || 0;
          b.totalQty += s['Billing Quantity'] || 0;

          if (!b.articles.has(articleId)) {
            b.articles.set(articleId, { description: s['Article Description'], qty: 0 });
          }
          b.articles.get(articleId)!.qty += s['Billing Quantity'] || 0;
        });

        // 4. Map to Analytics
        const analytics: BrandAnalytics[] = storeData.map(store => {
          const sales = brandSales.get(store.Brand) || { totalSales: 0, totalRGM: 0, totalQty: 0, articles: new Map() };
          
          // Get top 3 articles by qty
          const topArticles: ArticleStat[] = Array.from(sales.articles.entries())
            .sort((a, b) => b[1].qty - a[1].qty)
            .slice(0, 3)
            .map(([articleId, info]) => {
              const unitsSold = info.qty;
              const soh = sohMap.get(articleId) || 0;
              const velocity = unitsSold / weeks;
              // Sell rate can be zero if unitsSold is 0
              const nwc = velocity <= 0 ? (soh > 0 ? 99 : 0) : soh / velocity;
              const daysLeft = nwc * 7;
              
              let status: ArticleStat['status'] = 'HEALTHY';
              if (soh <= 0) status = 'OOS';
              else if (nwc < 2) status = 'CRITICAL';
              else if (nwc < 4) status = 'RISKY';

              return {
                articleId,
                description: info.description,
                unitsSold,
                soh,
                velocity,
                nwc,
                daysLeft,
                status
              };
            });

          const worstNWC = topArticles.length > 0 ? Math.min(...topArticles.map(a => a.soh <= 0 ? 0 : a.nwc)) : 99;
          
          let stockStatus: BrandAnalytics['stockStatus'] = 'HEALTHY';
          if (worstNWC <= 0) stockStatus = 'OOS';
          else if (worstNWC < 2) stockStatus = 'CRITICAL';
          else if (worstNWC < 4) stockStatus = 'RISKY';

          return {
            brand: store.Brand,
            fixtureId: store.Fixture,
            portfolio: store.Portfolio,
            sqFootage: store.Sq_Footage || 1,
            totalSales: sales.totalSales,
            totalRGM: sales.totalRGM,
            totalQty: sales.totalQty,
            spsf: sales.totalSales / (store.Sq_Footage || 1),
            gmrof: sales.totalRGM / (store.Sq_Footage || 1),
            contributionPct: 0, // Calculated later
            worstNWC,
            stockStatus,
            topArticles
          };
        });

        // 5. Calculate Contribution % and Percentiles
        const totalStoreSales = analytics.reduce((sum, b) => sum + b.totalSales, 0);
        analytics.forEach(b => {
          b.contributionPct = totalStoreSales === 0 ? 0 : (b.totalSales / totalStoreSales) * 100;
        });

        const latestRecord = salesData[salesData.length - 1];
        const lastDate = latestRecord ? `${latestRecord.Month} ${latestRecord.Year}` : 'No Date';

        const getPercentiles = (metric: keyof BrandAnalytics) => {
          const values = analytics.map(b => b[metric] as number).sort((a, b) => a - b);
          if (values.length === 0) return { p33: 0, p67: 0 };
          const p33 = values[Math.floor(values.length * 0.33)] || 0;
          const p67 = values[Math.floor(values.length * 0.67)] || 0;
          return { p33, p67 };
        };

        const percentiles = {
          SPSF: getPercentiles('spsf'),
          GMROF: getPercentiles('gmrof'),
          'Contribution %': getPercentiles('contributionPct')
        };

        resolve({ analytics, lastDate, weeks, percentiles });
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = reject;
    reader.readAsArrayBuffer(file);
  });
};

export const formatCurrency = (val: number) => {
  return new Intl.NumberFormat('en-IN', {
    maximumFractionDigits: 0,
    style: 'currency',
    currency: 'INR',
  }).format(val);
};

export const formatPercent = (val: number) => {
  return val.toFixed(1) + '%';
};

export const formatNumber = (val: number) => {
  return new Intl.NumberFormat('en-IN').format(val);
};

export const downloadExcelTemplate = (analytics: (BrandAnalytics | FixtureMeta)[]) => {
  // Fix 12: Generate Excel file with 3 sheets
  
  // Sheet 1: Store_data_template
  const storeHeader = ["Brand", "Fixture", "Portfolio", "Sq_Footage"];
  
  // Pre-fill with defaults if no data, otherwise use existing analytics
  let storeRows: any[][] = [];
  
  if (analytics.length > 0) {
    storeRows = analytics.map(b => [
      (b as BrandAnalytics).brand || "-",
      (b as BrandAnalytics).fixtureId || (b as FixtureMeta).fixtureRef || "-",
      (b as BrandAnalytics).portfolio || ((b as FixtureMeta).fixtureRef?.startsWith('Skin') ? 'Skin' : 'CC'),
      (b as BrandAnalytics).sqFootage || ""
    ]);
  } else {
    // Hardcoded defaults as requested
    storeRows = [
      ["Maybelline New York", "G1", "CC", ""],
      ["Kiro", "G1", "CC", ""],
      ["ROM&ND", "G1", "CC", ""],
      ["L'Oreal Paris", "G1", "CC", ""],
      ["Neutrogena", "G-2", "Skin", ""],
      ["CeraVe", "G-2", "Skin", ""],
      ["Simple", "G-2", "Skin", ""],
      ["The Ordinary", "G-2", "Skin", ""],
      ["Kay Beauty", "G-3", "CC", ""],
      ["Lagerfeld", "G-3", "CC", ""],
      ["Plum", "G-3", "CC", ""],
      ["SUGAR", "G-3", "CC", ""],
      ["Cetaphil", "G-4", "Skin", ""],
      ["Minimalist", "G-4", "Skin", ""],
      ["Dot & Key", "G-4", "Skin", ""],
      ["Wishful", "G-4", "Skin", ""]
    ];
  }

  const ws1 = XLSX.utils.aoa_to_sheet([storeHeader, ...storeRows]);

  // Sheet 2: Sales 
  const salesHeader = ["Date", "Month", "Year", "Brand", "Article ID", "Article Description", "Billing Quantity", "Net Sales", "Net Sales WOT", "RGM"];
  const ws2 = XLSX.utils.aoa_to_sheet([salesHeader]);

  // Sheet 3: SOH
  const sohHeader = ["Brand", "Article", "Article Description", "Saleable Qty"];
  const ws3 = XLSX.utils.aoa_to_sheet([sohHeader]);

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws1, "Store_data_template");
  XLSX.utils.book_append_sheet(wb, ws2, "Sales ");
  XLSX.utils.book_append_sheet(wb, ws3, "SOH");

  XLSX.writeFile(wb, "store_data_template.xlsx");
};
