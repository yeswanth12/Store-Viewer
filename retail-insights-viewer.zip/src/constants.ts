import { FixtureMeta } from './types';

export const COLORS = {
  red: { fill: '#E24B4A', stroke: '#A32D2D', text: '#FCEBEB' },
  amber: { fill: '#EF9F27', stroke: '#854F0B', text: '#412402' },
  green: { fill: '#3aaa6e', stroke: '#1a6e42', text: '#e8f8ef' },
  missing: '#D3D1C7',
  floor: '#e8e3da',
  floorContainer: '#f0ece3',
};

// G1: Purple, G-2: Teal/Coral, G-3: Pink, G-4: Blue/Amber
const GONDOLA_BASE_COLORS: Record<string, string> = {
  'G1': '#8b5cf6', // Indigo-500
  'G-2': '#14b8a6', // Teal-500
  'G-3': '#ec4899', // Pink-500
  'G-4': '#f59e0b', // Amber-500
};

export const BASE_FIXTURES: FixtureMeta[] = [
  // Top Wall: Skin Wallbays (4)
  { id: 'sw-1', fixtureRef: 'Skin Wallbay -1', type: 'wallbay', x: 20, y: 15, w: 90, h: 36 },
  { id: 'sw-2', fixtureRef: 'Skin Wallbay -2', type: 'wallbay', x: 112, y: 15, w: 90, h: 36 },
  { id: 'sw-3', fixtureRef: 'Skin Wallbay -3', type: 'wallbay', x: 204, y: 15, w: 90, h: 36 },
  { id: 'sw-4', fixtureRef: 'Skin Wallbay -4', type: 'wallbay', x: 296, y: 15, w: 90, h: 36 },

  // Top Wall: Fragrance Wallbays (3)
  { id: 'fw-1', fixtureRef: 'Wallbay Fragrance -1', type: 'wallbay', x: 390, y: 15, w: 52, h: 36 },
  { id: 'fw-2', fixtureRef: 'Wallbay Fragrance -2', type: 'wallbay', x: 444, y: 15, w: 52, h: 36 },
  { id: 'fw-3', fixtureRef: 'Wallbay Fragrance -3', type: 'wallbay', x: 498, y: 15, w: 52, h: 36 },

  // Gondolas G1 to G-4
  ...['G1', 'G-2', 'G-3', 'G-4'].flatMap((ref, i) => {
    const y = 100 + i * 90;
    const baseColor = GONDOLA_BASE_COLORS[ref];
    return [
      // Side A (Top row)
      { id: `${ref}-1`, fixtureRef: ref, type: 'gondola-segment', side: 'A', x: 150, y: y, w: 100, h: 32, defaultColor: baseColor },
      { id: `${ref}-2`, fixtureRef: ref, type: 'gondola-segment', side: 'A', x: 250, y: y, w: 100, h: 32, defaultColor: baseColor },
      // Side B (Bottom row)
      { id: `${ref}-3`, fixtureRef: ref, type: 'gondola-segment', side: 'B', x: 150, y: y + 32, w: 100, h: 32, defaultColor: baseColor },
      { id: `${ref}-4`, fixtureRef: ref, type: 'gondola-segment', side: 'B', x: 250, y: y + 32, w: 100, h: 32, defaultColor: baseColor },
    ] as FixtureMeta[];
  })
];
