export type MetricType = 'Performance' | 'SPSF' | 'GMROF' | 'Contribution %';

export type PortfolioType = 'CC' | 'Skin' | 'Fragrance';

export interface StoreRow {
  Brand: string;
  Fixture: string;
  Portfolio: PortfolioType;
  Sq_Footage: number;
}

export interface SalesRow {
  Date: number;
  Month: string;
  Year: number;
  Brand: string;
  'Article ID': string;
  'Article Description': string;
  'Billing Quantity': number;
  'Net Sales': number;
  'Net Sales WOT': number;
  RGM: number;
}

export interface SOHRow {
  Brand: string;
  Article: string;
  'Article Description': string;
  'Saleable Qty': number;
}

export interface ArticleStat {
  articleId: string;
  description: string;
  unitsSold: number;
  soh: number;
  velocity: number; // units/week
  nwc: number; // soh / velocity
  daysLeft: number; // nwc * 7
  status: 'OOS' | 'CRITICAL' | 'RISKY' | 'HEALTHY';
}

export interface BrandAnalytics {
  brand: string;
  fixtureId: string;
  portfolio: PortfolioType;
  sqFootage: number;
  totalSales: number;
  totalRGM: number;
  totalQty: number;
  spsf: number;
  gmrof: number;
  contributionPct: number;
  worstNWC: number;
  stockStatus: 'OOS' | 'CRITICAL' | 'RISKY' | 'HEALTHY';
  topArticles: ArticleStat[];
  lastDate?: string;
}

export interface FixtureMeta {
  id: string; // e.g., G1-1, G1-2... SW-1, SW-2
  fixtureRef: string; // Sheet1 Fixture label: G1, Skin Wallbay -1 etc.
  type: 'wallbay' | 'gondola-segment';
  brand?: string;
  x: number;
  y: number;
  w: number;
  h: number;
  side?: 'A' | 'B';
  defaultColor?: string;
}
